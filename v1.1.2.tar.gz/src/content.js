const evt = new CustomEvent('ChatGPTAuthHelperEvent', {});
window.dispatchEvent(evt);